#include "Weapon.h"

Weapon::Weapon(string file, float x, float y, Game* game)
	: Actor(file, x, y, 32, 32, game) {
	
	animation = new Animation(file, width, height,
		32, 32, 1, 1, true, game);
}

void Weapon::update() {
	bool endAnimation = animation->update();
	vy = -1;
}

void Weapon::draw(double scrollX) {
	animation->draw(x - scrollX, y);
}

float Weapon::getTime() {
	return -1;
}

int Weapon::getTypeShoot() {
	return -1;
}

