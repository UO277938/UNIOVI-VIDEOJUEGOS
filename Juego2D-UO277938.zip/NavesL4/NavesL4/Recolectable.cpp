#include "Recolectable.h"

Recolectable::Recolectable(float x, float y, Game* game)
	: Actor("res/icono_recolectable.png", x, y, 20, 20, game) {


	animation = new Animation("res/moneda_animacion.png", 20, 20,
		127, 16, 6, 8, true, game);

}

void Recolectable::update() {
	bool endAnimation = animation->update();
	if (endAnimation)
		value = 0;
	vy = -1;
}

void Recolectable::draw(double scrollX) {
	animation->draw(x - scrollX, y);
}


