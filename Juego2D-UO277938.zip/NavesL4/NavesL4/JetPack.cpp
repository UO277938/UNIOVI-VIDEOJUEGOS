#include "JetPack.h"

JetPack::JetPack(float x, float y, Game* game)
	: Actor("res/orb_yellow.png", x, y, 32, 32, game) {


	animation = new Animation("res/orb_yellow.png", width, height,
		32, 32, 1, 1, true, game);

}

void JetPack::update() {
	bool endAnimation = animation->update();
}

void JetPack::draw(double scrollX) {
	animation->draw(x - scrollX, y);
}


