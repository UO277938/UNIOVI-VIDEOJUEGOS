#pragma once

#include "Enemy.h"
#include "Animation.h" 

class EnemyExplosive : virtual public Enemy
{
public:
	EnemyExplosive(float x, float y, Game* game);
	void draw(float scrollX = 0) override; // Va a sobrescribir
	void update(float x, float y) override;
	void impacted() override; // Recibe impacto y pone animaci�n de morir
	void jump();

	float vxIntelligence;
	int state;
	Animation* aDying;
	Animation* aMoving;
	Animation* aExplode;
	Animation* animation; // Referencia a la animaci�n mostrada

	int timeJump = 10;
	double onAir;
};
