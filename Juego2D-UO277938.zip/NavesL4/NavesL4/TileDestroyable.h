#pragma once
#include "Actor.h"

class TileDestroyable : public Actor
{
public:
	TileDestroyable(string filename, float x, float y, Game* game);
	void update();

	int delay = 30;

	bool toDestroy = false;
};

