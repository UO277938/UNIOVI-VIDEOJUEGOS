#pragma once

#include "ProjectilePlayer.h"

class ProjectilePlayerRay : virtual public ProjectilePlayer
{
public:
	ProjectilePlayerRay(float x, float y, Game* game);
	void update() override;
};

