#pragma once

#include "Layer.h"
#include "Player.h"
#include "Background.h"

#include "Enemy.h"
#include "EnemyStandard.h"
#include "EnemyShooter.h"
#include "EnemyFlying.h"
#include "EnemyExplosive.h"
#include "EnemyChaser.h"

#include "ProjectileEnemy.h"
#include "ProjectilePlayer.h"
#include "ProjectileControls.h"

#include "Recolectable.h"
#include "JetPack.h"

#include "Weapon.h"
#include "WeaponRay.h"
#include "WeaponHoming.h"
#include "WeaponMoving.h"
#include "WeaponMelee.h"

#include "Text.h"

#include "Tile.h"
#include "TileShootable.h"
#include "TileDestroyable.h"

#include "Pad.h"

#include "Audio.h"
#include "Space.h" // importar

#include <fstream> // Leer ficheros
#include <sstream> // Leer l�neas / String
#include <list>

class GameLayer : public Layer
{
public:
	GameLayer(Game* game);
	void init() override;
	void processControls() override;
	void update() override;
	void draw() override;
	void keysToControls(SDL_Event event);
	void mouseToControls(SDL_Event event); // USO DE MOUSE
	void gamePadToControls(SDL_Event event); // USO DE GAMEPAD
	void loadMap(string name);
	void loadMapObject(char character, float x, float y);
	void calculateScroll();
	Actor* message;
	bool pause;
	// Elementos de interfaz
	SDL_GameController* gamePad;
	Pad* pad;
	Actor* buttonJump;
	Actor* buttonShoot;

	Tile* cup; // Elemento de final de nivel
	Space* space;
	float scrollX;
	int mapWidth;

	list<Tile*> tiles;
	list<TileDestroyable*> tilesDestroyable;
	list<TileShootable*> tilesShootable;

	Audio* audioBackground;
	Text* textPoints;
	int points;
	int newEnemyTime = 0;
	Player* player;
	Background* background;
	Actor* backgroundPoints;
	list<Enemy*> enemies;

	list<Recolectable*> items;
	list<JetPack*> jets;

	list<Weapon*> weapons;

	list<ProjectilePlayer*> projectilesPlayer;
	list<ProjectileEnemy*> projectilesEnemy;

	bool controlContinue = false;
	bool controlShoot = false;
	int controlMoveY = 0;
	int controlMoveX = 0;

	bool controlsToProjectile = false;

	ProjectilePlayer* playerShoot();

	float timeWeapon;

	ProjectileControls* projControls;

};

