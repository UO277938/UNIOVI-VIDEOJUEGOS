#pragma once

#include "Actor.h"
#include "Animation.h"

class ProjectileControls : public Actor
{
public:
	ProjectileControls(float x, float y, Game* game);
	void update();
	void draw(double scrollX);
	void moveX(float axis);
	void moveY(float axis);
	void jump();

	Animation* animation;

	int time = 250;
};

