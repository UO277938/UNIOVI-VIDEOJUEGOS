#pragma once

#include "Actor.h"


class ProjectilePlayer : public Actor
{
public:
	ProjectilePlayer(string file, int width, int height, float x, float y, Game* game);
	virtual void update();


	bool autodestroy = false;
};

