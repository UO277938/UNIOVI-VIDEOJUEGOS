#pragma once

#include "Weapon.h"

class WeaponRay : virtual public Weapon
{
public:
	WeaponRay(float x, float y, Game* game);

	float getTime() override;
	int getTypeShoot() override;
};


