#include "ProjectilePlayerMelee.h"

ProjectilePlayerMelee::ProjectilePlayerMelee(float x, float y, Game* game) :
	ProjectilePlayer("res/disparo_jugador.png", 32, 32, x, y, game) {
	vx = 3;
	vy = -1; // La gravedad inicial es 1
}

void ProjectilePlayerMelee::update() {
	if (meleeTime <= 0) {
		autodestroy = true;
		return;
	}
	vy = 3.3;
	meleeTime--;
}

