#pragma once

#include "Weapon.h"

class WeaponMelee : virtual public Weapon
{
public:
	WeaponMelee(float x, float y, Game* game);

	float getTime() override;
	int getTypeShoot() override;
};


