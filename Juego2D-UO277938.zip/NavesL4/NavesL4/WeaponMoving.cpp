#include "WeaponMoving.h"

WeaponMoving::WeaponMoving(float x, float y, Game* game)
	: Weapon("res/orb_red.png", x, y, game) {

}

float WeaponMoving::getTime() {
	return 200;
}

int WeaponMoving::getTypeShoot() {
	return 3;
}


