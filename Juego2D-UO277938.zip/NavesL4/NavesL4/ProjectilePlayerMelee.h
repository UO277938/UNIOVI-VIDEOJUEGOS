#pragma once

#include "ProjectilePlayer.h"
#include "Enemy.h"

class ProjectilePlayerMelee : virtual public ProjectilePlayer
{
public:
	ProjectilePlayerMelee(float x, float y, Game* game);
	void update() override;
	
	int meleeTime = 5;
};

