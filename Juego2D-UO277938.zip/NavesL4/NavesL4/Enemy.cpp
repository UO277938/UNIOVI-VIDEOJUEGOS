#include "Enemy.h"

Enemy::Enemy(string file, float x, float y, int width, int height, Game* game) 
	: Actor(file, x, y, width, height, game) {

}

void Enemy::update() {

}

void Enemy::update(float x, float y) {

}

void Enemy::impacted() {

}


void Enemy::draw(float scrollX) {
}

ProjectileEnemy* Enemy::shoot(){
	return NULL;
}


