#pragma once

#include "Enemy.h".
#include "Animation.h" 

class EnemyChaser : virtual public Enemy
{
public:
	EnemyChaser( float x, float y, Game* game);
	void draw(float scrollX = 0) override; // Va a sobrescribir
	void update(float x, float y) override;
	void impacted() override; // Recibe impacto y pone animaci�n de morir

	float vxIntelligence;
	int state;

	Animation* aDying;
	Animation* aMoving;
	Animation* animation; // Referencia a la animaci�n mostrada
};
