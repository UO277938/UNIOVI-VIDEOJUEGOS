#pragma once

#include "Actor.h"
#include "Animation.h" 

class JetPack : public Actor
{
public:
	JetPack(float x, float y, Game* game);
	void update();
	void draw(double scrollX);

	Animation* animation;

	int value = 25;
};


