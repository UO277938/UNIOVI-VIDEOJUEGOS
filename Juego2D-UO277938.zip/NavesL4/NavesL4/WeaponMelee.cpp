#include "WeaponMelee.h"

WeaponMelee::WeaponMelee(float x, float y, Game* game)
	: Weapon("res/orb_yellow.png", x, y, game) {

}

float WeaponMelee::getTime() {
	return 220;
}

int WeaponMelee::getTypeShoot() {
	return 6;
}


