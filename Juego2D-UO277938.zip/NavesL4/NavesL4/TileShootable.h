#pragma once
#include "Actor.h"

class TileShootable : public Actor
{
public:
	TileShootable(string filename, float x, float y, Game* game);
	void update();

	bool toDestroy = false;
};

