#pragma once

#include "ProjectilePlayer.h"
#include "Player.h"

class ProjectilePlayerArround : virtual public ProjectilePlayer
{
public:
	ProjectilePlayerArround(float x, float y, Game* game);
	void update() override;

	//Player* jugador;

	float timeMovement = 50000;

	float minDis = 100;
	float maxDis = 220;
};

