#include "ProjectilePlayerRay.h"

ProjectilePlayerRay::ProjectilePlayerRay(float x, float y, Game* game) :
	ProjectilePlayer("res/disparo_jugador.png", 20, 20, x, y, game) {
	vx = 9;
	vy = -1; // La gravedad inicial es 1
}

void ProjectilePlayerRay::update() {
	vy = - 1; // La gravedad suma 1 en cada actualizaci�n restamos para anularla 
}
