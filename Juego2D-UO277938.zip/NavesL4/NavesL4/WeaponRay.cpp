#include "WeaponRay.h"

WeaponRay::WeaponRay(float x, float y, Game* game)
	: Weapon("res/orb_red.png", x, y, game) {

}

float WeaponRay::getTime() {
	return 100;
}

int WeaponRay::getTypeShoot() {
	return 2;
}


