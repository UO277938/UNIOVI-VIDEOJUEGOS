#include "WeaponHoming.h"

WeaponHoming::WeaponHoming(float x, float y, Game* game)
	: Weapon("res/orb_blue.png", x, y, game) {

}

float WeaponHoming::getTime() {
	return 150;
}

int WeaponHoming::getTypeShoot() {
	return 5;
}


