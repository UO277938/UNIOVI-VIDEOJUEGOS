#include "TileDestroyable.h"
#include <iostream>
using namespace std;

TileDestroyable::TileDestroyable(string filename, float x, float y, Game* game)
	: Actor(filename, x, y, 40, 32, game) {
}

void TileDestroyable::update() {
	if (collisionUp) {
		toDestroy = true;
		delay--;
	}
}
