#include "ProjectilePlayerHoming.h"

ProjectilePlayerHoming::ProjectilePlayerHoming(Enemy* enemyHoming, float x, float y, Game* game) :
	ProjectilePlayer("res/disparo_jugador2.png", 20, 20, x, y, game) {
	vx = 2;
	vy = -1; // La gravedad inicial es 1
	this->enemyHoming = enemyHoming;
}

void ProjectilePlayerHoming::update() {
	if (enemyHoming->state == game->stateDying || enemyHoming->state == game->stateDead) {
		autodestroy = true;
		return;
	}

	vx = 0;
	vy = -1;
	if (x < enemyHoming->x) {
		vx = vx + 2;
	}
	else
		vx = vx - 2;

	if (y < enemyHoming->y) {
		vy = vy + 2;
	}
	else
		vy = vy - 2;

	vy = vy - 1; // La gravedad suma 1 en cada actualizaci�n restamos para anularla 
	cout << "ACTUALIZA EL TIRO" << endl;

}

