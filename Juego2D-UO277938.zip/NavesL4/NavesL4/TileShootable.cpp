#include "TileShootable.h"
#include <iostream>
using namespace std;

TileShootable::TileShootable(string filename, float x, float y, Game* game)
	: Actor(filename, x, y, 40, 32, game) {

}

void TileShootable::update() {
	if (collisionLeft || collisionRight || collisionDown || collisionUp) {
		toDestroy = true;
	}
}
