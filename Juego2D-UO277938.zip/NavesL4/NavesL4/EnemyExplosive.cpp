#include "EnemyExplosive.h"

EnemyExplosive::EnemyExplosive(float x, float y, Game* game)
	: Enemy("res/enemigo.png", x, y, 36, 40, game) {

	state = game->stateMoving;

	onAir = false;

	aDying = new Animation("res/pajaroRojoMuerto.png", width, height,
		50, 27, 10, 1, true, game);

	aExplode = new Animation("res/explosion.png", 130, 130,
		500, 500, 1, 1, true, game);

	aMoving = new Animation("res/pajaroRojo.png", width, height,
		96, 23, 6, 3, true, game);
	animation = aMoving;

	vx = 2.5;
	vxIntelligence = 2.5;
	vx = vxIntelligence;

}

void EnemyExplosive::update(float xPlayer, float yPlayer) {
	// Actualizar la animaci�n
	bool endAnimation = animation->update();

	// Acabo la animaci�n, no sabemos cual
	if (endAnimation) {
		// Estaba muriendo
		if (state == game->stateDying) {
			state = game->stateDead;
		}
	}

	if (collisionDown == true) {
		onAir = false;
	}
	else {
		onAir = true;
	}

	if (collisionRight) {
		impacted();
	}


	if (state == game->stateMoving) {
		animation = aMoving;
	}
	if (state == game->stateDying) {
		animation = aExplode;
	}

	if (x > xPlayer + 50) {
		impacted();
	}

	// Establecer velocidad
	if (state != game->stateDying) {
		// no est� muerto y se ha quedado parado
		if (vx == 0) {
			vx = -1;
		}

		timeJump--;
		if (timeJump <= 0) {
			jump();
			timeJump = 14;
		}
	}
	else {
		vx = 0;
	}



}

void EnemyExplosive::impacted() {
	if (state != game->stateDying) {
		state = game->stateDying;
	}
}


void EnemyExplosive::draw(float scrollX) {
	animation->draw(x - scrollX, y);
}

void EnemyExplosive::jump() {
	vy += -18;
}


