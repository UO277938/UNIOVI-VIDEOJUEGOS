#pragma once

#include "Weapon.h"

class WeaponHoming : virtual public Weapon
{
public:
	WeaponHoming(float x, float y, Game* game);

	float getTime() override;
	int getTypeShoot() override;
};


