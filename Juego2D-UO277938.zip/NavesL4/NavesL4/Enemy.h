#pragma once

#include "Actor.h"
#include "Animation.h" 
#include "ProjectileEnemy.h"

class Enemy : public Actor
{
public:
	Enemy(string file, float x, float y, int width, int height, Game* game);
	virtual void draw(float scrollX = 0) override; // Va a sobrescribir
	virtual void update();
	virtual void update(float x, float y);
	virtual void impacted(); // Recibe impacto y pone animaci�n de morir
	virtual ProjectileEnemy* shoot();

	float vxIntelligence;
	int state;
	Animation* aDying;
	Animation* aMoving;
	Animation* animation; // Referencia a la animaci�n mostrada
};
