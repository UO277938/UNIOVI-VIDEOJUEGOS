#include "EnemyChaser.h"

EnemyChaser::EnemyChaser(float x, float y, Game* game)
	: Enemy("res/enemigo.png", x, y, 36, 40, game) {

	state = game->stateMoving;

	aDying = new Animation("res/enemigo_morir.png", width, height,
		280, 40, 6, 8, false, game);

	aMoving = new Animation("res/enemigo_movimiento.png", width, height,
		108, 40, 6, 3, true, game);
	animation = aMoving;

	vx = 1;
	vxIntelligence = -1;
	vx = vxIntelligence;

}

void EnemyChaser::update(float x, float y) {
	// Actualizar la animaci�n
	bool endAnimation = animation->update();

	// Acabo la animaci�n, no sabemos cual
	if (endAnimation) {
		// Estaba muriendo
		if (state == game->stateDying) {
			state = game->stateDead;
		}
	}


	if (state == game->stateMoving) {
		animation = aMoving;
	}
	if (state == game->stateDying) {
		animation = aDying;
	}

	// Establecer velocidad
	if (state != game->stateDying) {
		vx = 0;
		vy = -1;
		if (this->x < x) { //DERECHA
			cout << "HACIA LA DERECHA" << endl;
			vx = vx + 2;
		}
		else //IZQUIERDA
			vx = vx - 2;

		if (this->y < y) { //ABAJO
			cout << "HACIA ABAJO" << endl;
			vy = vy + 2;
		}
		else
			vy = vy - 2; //ARRIBA

		vy = vy - 1; // La gravedad suma 1 en cada actualizaci�n restamos para anularla 
		cout << "ACTUALIZA ENEMIGO CAZADOR" << endl;

	}
	else {
		vx = 0;
	}



}

void EnemyChaser::impacted() {
	if (state != game->stateDying) {
		state = game->stateDying;
	}
}


void EnemyChaser::draw(float scrollX) {
	animation->draw(x - scrollX, y);
}


