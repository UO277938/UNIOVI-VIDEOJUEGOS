#pragma once

#include "Actor.h"
#include "ProjectilePlayer.h" 
#include "ProjectilePlayerStandard.h" 
#include "ProjectilePlayerRay.h"
#include "ProjectilePlayerArround.h"
#include "ProjectilePlayerHoming.h"
#include "ProjectilePlayerMelee.h"

#include "Audio.h"
#include "Enemy.h"
#include "Animation.h" // incluir animacion 

class Player : public Actor
{
public:
	Player(float x, float y, Game* game);

	ProjectilePlayer* shoot();
	ProjectilePlayer* shootRay();
	ProjectilePlayer* shootHoming(Enemy* enemyHoming);
	ProjectilePlayer* shootMovement();
	ProjectilePlayer* shootMelee();
	ProjectilePlayer* shootArround();


	void update();
	void jet();
	void jump();
	void stayStill();
	void moveX(float axis);
	void moveY(float axis);
	void draw(float scrollX = 0) override; // Va a sobrescribir
	void loseLife();
	void fallJetpack();

	int lifes = 3;
	int invulnerableTime = 0;
	bool onAir;
	int orientation;
	int state;
	Animation* aIdleRight;
	Animation* aIdleLeft;
	Animation* aJumpingRight;
	Animation* aJumpingLeft;
	Animation* aRunningRight;
	Animation* aRunningLeft;
	Animation* aShootingRight;
	Animation* aShootingLeft;
	Animation* animation; // Referencia a la animaci�n mostrada
	Audio* audioShoot;
	int shootCadence = 50;
	int shootTime = 0;

	int actualShot = 1;

	int standardShot = 1;
	int rayShot = 2;
	int movementShot = 3;
	int arroundShot = 4;
	int homingShot = 5;
	int meleeShot = 6;

	int stateJetpack = true; //si tiene jetpack

};

