#include "ProjectileControls.h"

#include <iostream>
using namespace std;

ProjectileControls::ProjectileControls(float x, float y, Game* game) :
	Actor("res/orb_red.png", x, y, 32, 32, game) {
	
	animation = new Animation("res/orb_red.png", width, height,
		32, 32, 1, 1, true, game);
}

void ProjectileControls::update() {
	bool endAnimation = animation->update();
	time--;
	cout << "SE ACTUALIZA EL DISPARO CONTROLES" << endl;
}

void ProjectileControls::draw(double scrollX) {
	animation->draw(x - scrollX, y);

}

void ProjectileControls::moveX(float axis) {
	vx = axis * 3.2;
}

void ProjectileControls::moveY(float axis) {
	vy = axis * 4.5;
	if (axis == 0) {
		vy = 1;
	}
}

void ProjectileControls::jump() {
	vy += -3;
}