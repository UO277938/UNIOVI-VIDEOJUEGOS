#pragma once

#include "Weapon.h"

class WeaponMoving : virtual public Weapon
{
public:
	WeaponMoving(float x, float y, Game* game);

	float getTime() override;
	int getTypeShoot() override;
};


