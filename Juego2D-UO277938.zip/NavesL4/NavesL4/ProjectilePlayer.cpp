#include "ProjectilePlayer.h"

ProjectilePlayer::ProjectilePlayer(string file, int width, int height, float x, float y, Game* game) :
	Actor(file, x, y, width, height, game) {

}

void ProjectilePlayer::update() {
}
