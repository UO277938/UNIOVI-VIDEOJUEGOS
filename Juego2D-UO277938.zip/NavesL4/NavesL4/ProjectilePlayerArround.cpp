#include "ProjectilePlayerArround.h"

ProjectilePlayerArround::ProjectilePlayerArround(float x, float y, Game* game) :
	ProjectilePlayer("res/disparo_jugador2.png", 20, 20, x, y, game) {
	vx = 9;
	vy = -1; // La gravedad inicial es 1

	//this->jugador = jugador;
}

void ProjectilePlayerArround::update() {

	if (timeMovement <= 0) {
		autodestroy = true;
		return;
	}

	vx = -2;
	vy = -1;
	//DISPARO A LA IZQUIERDA
	/**if (x < jugador->x) {
		//ESTA MUY CERCA
		if ((jugador->x - x) < minDis) {
			vx = vx - 2;
		}//ESTA DISTANCIA CORRECTA
		if ((jugador->x - x) > maxDis) {
			vx = 0;
			vy = vy + 2;
		}
	}


	if (y < jugador->y) {
		vy = vy + 2;
	}
	else
		vy = vy - 2;
	*/
	//vy = vy - 1; // La gravedad suma 1 en cada actualizaci�n restamos para anularla 
	cout << "ACTUALIZA EL TIRO" << endl;
}
