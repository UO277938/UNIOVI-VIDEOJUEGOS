#pragma once

#include "ProjectilePlayer.h"

class ProjectilePlayerStandard : virtual public ProjectilePlayer
{
public:
	ProjectilePlayerStandard(float x, float y, Game* game);
	void update() override;
};

