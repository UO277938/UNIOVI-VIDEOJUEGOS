#pragma once

#include "Actor.h"
#include "Animation.h" 

class Weapon : public Actor
{
public:
	Weapon(string file, float x, float y, Game* game);
	void update();
	void draw(double scrollX);

	virtual float getTime();
	virtual int getTypeShoot();

	Animation* animation;
};


