#include "EnemyShooter.h"

EnemyShooter::EnemyShooter(float x, float y, Game* game)
	: Enemy("res/enemigo_shooter.png", x, y, 36, 40, game) {

	state = game->stateMoving;

	audioShoot = new Audio("res/efecto_disparo.wav", false);

	aDying = new Animation("res/enemigo_morir_shooter.png", width, height,
		280, 40, 6, 8, false, game);

	aMoving = new Animation("res/enemigo_movimiento_shooter.png", width, height,
		108, 40, 6, 3, true, game);
	animation = aMoving;

	vx = 2;
	vxIntelligence = 2;
	vx = vxIntelligence;

}

void EnemyShooter::update(float x, float y) {
	// Actualizar la animaci�n
	bool endAnimation = animation->update();

	// Acabo la animaci�n, no sabemos cual
	if (endAnimation) {
		// Estaba muriendo
		if (state == game->stateDying) {
			state = game->stateDead;
		}
	}


	if (state == game->stateMoving) {
		animation = aMoving;
	}
	if (state == game->stateDying) {
		animation = aDying;
	}

	// Establecer velocidad
	if (state != game->stateDying) {
		vy = -1;
		vx = 2.5;

	}
	else {
		vx = 0;
	}

	//Si golpea con algo por la derecha
	if (collisionRight)
		impacted();

}

void EnemyShooter::impacted() {
	if (state != game->stateDying) {
		state = game->stateDying;
	}
}


ProjectileEnemy* EnemyShooter::shoot() {
	shootTime--;
	if (shootTime <= 0) {
		state = game->stateShooting;
		//audioShoot->play();
		shootTime = shootCadence;
		ProjectileEnemy* projectile = new ProjectileEnemy(x, y, game);
		if (vx<0) {
			projectile->vx = projectile->vx * -1; // Invertir
		}
		return projectile;
	}
	else {
		return NULL;
	}
}

void EnemyShooter::draw(float scrollX) {
	animation->draw(x - scrollX, y);
}


