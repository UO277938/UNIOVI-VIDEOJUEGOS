#pragma once

#include "ProjectilePlayer.h"
#include "Enemy.h"

class ProjectilePlayerHoming : virtual public ProjectilePlayer
{
public:
	ProjectilePlayerHoming(Enemy* enemyHoming, float x, float y, Game* game);
	void update() override;

	Enemy* enemyHoming;
};

