#include "EnemyStandard.h"

EnemyStandard::EnemyStandard(float x, float y, Game* game)
	: Enemy("res/enemigo.png", x, y, 36, 40, game) {

	state = game->stateMoving;

	aDying = new Animation("res/enemigo_morir.png", width, height,
		280, 40, 6, 8, false, game);

	aMoving = new Animation("res/enemigo_movimiento.png", width, height,
		108, 40, 6, 3, true, game);
	animation = aMoving;

	vx = 1;
	vxIntelligence = -1;
	vx = vxIntelligence;

}

void EnemyStandard::update(float xPlayer, float yPlayer) {
	// Actualizar la animaci�n
	bool endAnimation = animation->update();

	// Acabo la animaci�n, no sabemos cual
	if (endAnimation) {
		// Estaba muriendo
		if (state == game->stateDying) {
			state = game->stateDead;
		}
	}


	if (state == game->stateMoving) {
		animation = aMoving;
	}
	if (state == game->stateDying) {
		animation = aDying;
	}

	// Establecer velocidad
	if (state != game->stateDying) {
		
		vy = -1;
		if (x - xPlayer > 124) {
			left = true;
			cout << "LEFT" << endl;
		}
		if (x - xPlayer < -320) {
			left = false;
			cout << "RIGHT" << endl;
		}

		if (left == true)
			vx = -3.3;
		else
			vx = 4;
	}
	else {
		vx = 0;
	}



}

void EnemyStandard::impacted() {
	if (state != game->stateDying) {
		state = game->stateDying;
	}
}


void EnemyStandard::draw(float scrollX) {
	animation->draw(x - scrollX, y);
}


